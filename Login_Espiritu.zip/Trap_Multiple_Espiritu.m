% trapezoidal rule multiple
% I = (b-a)[f(a)+f(b)]/2

clear, clc
f = @(x)  0.2 + 25*x - 200*x^2 +675*x^3-900*x^4+400*x^5;
xo = input("Input lower limit: ");
xn = input("Input upper limit: ");
n = input("Enter number of intervals: ");
h = (xn - xo) / n;
s = f(xo) + f(xn);

for i = 1:n-1
    s = s + 2 * f(xo + i*h);
end
I = h/2 * s;
fprintf('The approximate integral is: %f\n', I);
