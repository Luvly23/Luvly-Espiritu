﻿Imports MySql.Data.MySqlClient
Public Class Form1
    Dim mySqlCon As String = "server=127.0.0.1;user=root;database=user_db;password="
    Dim mySqlConnection As New MySqlConnection(mySqlCon)
    Dim dataSet As New DataSet()

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadData()
    End Sub

    Private Sub LoadData()
        Try

            mySqlConnection.Open()


            Dim selectQuery As String = "SELECT * FROM user_tbl"


            Dim cmd As New MySqlCommand(selectQuery, mySqlConnection)


            Dim dataAdapter As New MySqlDataAdapter(cmd)

            dataSet.Clear()


            dataAdapter.Fill(dataSet, "user_tbl")


            dgv_users.DataSource = Nothing


            dgv_users.DataSource = dataSet.Tables("user_tbl")

        Catch ex As Exception
            MessageBox.Show("Error loading data: " & ex.Message)
        Finally

            mySqlConnection.Close()
        End Try
    End Sub

    Private Sub btn_login_Click(sender As Object, e As EventArgs) Handles btn_login.Click
        Try

            mySqlConnection.Open()

            Dim insertQuery As String = "INSERT INTO user_tbl (`Full Name`, Username, Password) VALUES (@FullName, @Username, @Password)"


            Dim cmd As New MySqlCommand(insertQuery, mySqlConnection)


            cmd.Parameters.AddWithValue("@FullName", txt_fname.Text)
            cmd.Parameters.AddWithValue("@Username", txt_uname.Text)
            cmd.Parameters.AddWithValue("@Password", txt_password.Text)


            cmd.ExecuteNonQuery()

            MessageBox.Show("Data inserted successfully.")

            ' Clear the textboxes after successful insertion
            txt_fname.Clear()
            txt_uname.Clear()
            txt_password.Clear()

            LoadData()

        Catch ex As Exception
            MessageBox.Show("Error inserting data: " & ex.Message)
        Finally

            mySqlConnection.Close()
        End Try
    End Sub


End Class
