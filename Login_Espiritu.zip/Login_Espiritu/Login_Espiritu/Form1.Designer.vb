﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        txt_fname = New TextBox()
        txt_uname = New TextBox()
        txt_ID = New TextBox()
        txt_password = New TextBox()
        btn_login = New Button()
        dgv_users = New DataGridView()
        Column1 = New DataGridViewTextBoxColumn()
        Column2 = New DataGridViewTextBoxColumn()
        Column3 = New DataGridViewTextBoxColumn()
        Column4 = New DataGridViewTextBoxColumn()
        lbl_fname = New Label()
        Label1 = New Label()
        Label2 = New Label()
        CType(dgv_users, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' txt_fname
        ' 
        txt_fname.Location = New Point(33, 54)
        txt_fname.Name = "txt_fname"
        txt_fname.Size = New Size(100, 23)
        txt_fname.TabIndex = 0
        ' 
        ' txt_uname
        ' 
        txt_uname.Location = New Point(33, 107)
        txt_uname.Name = "txt_uname"
        txt_uname.Size = New Size(100, 23)
        txt_uname.TabIndex = 1
        ' 
        ' txt_ID
        ' 
        txt_ID.Location = New Point(12, 215)
        txt_ID.Name = "txt_ID"
        txt_ID.Size = New Size(21, 23)
        txt_ID.TabIndex = 2
        txt_ID.Visible = False
        ' 
        ' txt_password
        ' 
        txt_password.Location = New Point(33, 163)
        txt_password.Name = "txt_password"
        txt_password.Size = New Size(100, 23)
        txt_password.TabIndex = 3
        ' 
        ' btn_login
        ' 
        btn_login.BackColor = Color.Peru
        btn_login.Font = New Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btn_login.Location = New Point(506, 192)
        btn_login.Name = "btn_login"
        btn_login.Size = New Size(97, 39)
        btn_login.TabIndex = 4
        btn_login.Text = "Login"
        btn_login.UseVisualStyleBackColor = False
        ' 
        ' dgv_users
        ' 
        dgv_users.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        dgv_users.Columns.AddRange(New DataGridViewColumn() {Column1, Column2, Column3, Column4})
        dgv_users.Location = New Point(160, 36)
        dgv_users.Name = "dgv_users"
        dgv_users.Size = New Size(443, 150)
        dgv_users.TabIndex = 5
        ' 
        ' Column1
        ' 
        Column1.HeaderText = "ID"
        Column1.Name = "Column1"
        ' 
        ' Column2
        ' 
        Column2.HeaderText = "Full Name"
        Column2.Name = "Column2"
        ' 
        ' Column3
        ' 
        Column3.HeaderText = "Username"
        Column3.Name = "Column3"
        ' 
        ' Column4
        ' 
        Column4.HeaderText = "Password"
        Column4.Name = "Column4"
        ' 
        ' lbl_fname
        ' 
        lbl_fname.AutoSize = True
        lbl_fname.Location = New Point(33, 36)
        lbl_fname.Name = "lbl_fname"
        lbl_fname.Size = New Size(61, 15)
        lbl_fname.TabIndex = 6
        lbl_fname.Text = "Full Name"
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(33, 89)
        Label1.Name = "Label1"
        Label1.Size = New Size(60, 15)
        Label1.TabIndex = 7
        Label1.Text = "Username"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(33, 139)
        Label2.Name = "Label2"
        Label2.Size = New Size(57, 15)
        Label2.TabIndex = 8
        Label2.Text = "Password"
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.SeaShell
        ClientSize = New Size(618, 236)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Controls.Add(lbl_fname)
        Controls.Add(dgv_users)
        Controls.Add(btn_login)
        Controls.Add(txt_password)
        Controls.Add(txt_ID)
        Controls.Add(txt_uname)
        Controls.Add(txt_fname)
        Name = "Form1"
        Text = "Login"
        TransparencyKey = Color.FromArgb(CByte(255), CByte(255), CByte(192))
        CType(dgv_users, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents txt_fname As TextBox
    Friend WithEvents txt_uname As TextBox
    Friend WithEvents txt_ID As TextBox
    Friend WithEvents txt_password As TextBox
    Friend WithEvents btn_login As Button
    Friend WithEvents dgv_users As DataGridView
    Friend WithEvents Column1 As DataGridViewTextBoxColumn
    Friend WithEvents Column2 As DataGridViewTextBoxColumn
    Friend WithEvents Column3 As DataGridViewTextBoxColumn
    Friend WithEvents Column4 As DataGridViewTextBoxColumn
    Friend WithEvents lbl_fname As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label

End Class
